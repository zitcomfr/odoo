# -*- coding: utf-8 -*-
from openerp.tools import config


def run(session, logger):
    """Update all modules."""
    if session.is_initialization:
        config['load_language'] = 'fr_FR'
        modules = [
            'fraichementbon',
            'attachment_large_object',
            'disable_openerp_online',
        ]
        session.install_modules(modules)
        logger.info(
            "Fresh database ! Installing Fraîchement Bon - modules: %r",
            modules
        )
        fraichementbon_initialization(session, logger)
        session.env.cr.commit()
        return
    # specific case
    logger.info("Default upgrade procedure : updating all modules.")

    # expected installed module for a given version
    ins_modules_version = {
        '0.7': ['report_custom_filename'],
    }

    up_modules = ['all']
    ins_modules = []

    for version, module in ins_modules_version.items():
        if session.db_version <= version:
            ins_modules.extend('report_custom_filename')

    if ins_modules:
        session.update_modules_list()
        logger.info("installing modules %r", ins_modules)
        session.install_modules(ins_modules)

    if up_modules:
        logger.info("updating modules %r", up_modules)
        session.update_modules(up_modules)

    # I don't remember if this is necessary, anyway we commit!
    session.cr.commit()


def fraichementbon_initialization(session, logger):
    """This method intent to be called on fresh install for database
    initialisation

    This aims to be easier to maintains and debug than yaml file.

    what we do here:
    * thousands sep NARROW NO-BREAK SPACE'
    * initialize frensh compta
    * force ir.actions.todo to done!
    """
    logger.info("set tousands sepearator without break space")
    fr_lang = session.env['res.lang'].search([('code', '=', 'fr_FR')])
    fr_lang.write({'thousands_sep': u' ', 'grouping': '[3,3,3,3,3,3]'})

    logger.info("Install frensh account")
    account_start_date = '2016-01-01'
    account_end_date = '2016-12-31'
    account_period = 'month'
    if session.with_demo:
        # PV: move existing fiscallyear and period before create new once
        # to ovoid period overlaping in demo data
        year = '2015'
        # I know there is only one create in demo data
        fiscalyear = session.env['account.fiscalyear'].search([])
        fiscalyear.write(
            {
                'date_start': '2015-01-01',
                'date_stop': '2015-12-31',
            }
        )
        for period in session.env['account.period'].search([]):
            datestop = year + period.date_stop[4:]
            if datestop[5:7] == '02':
                datestop = year + '-02-28'
            period.write(
                {
                    'date_start': year + period.date_start[4:],
                    'date_stop': datestop,
                }
            )
    account_installer_todo = session.env.ref(
        'account.account_configuration_installer_todo'
    )
    if account_installer_todo.state == 'open':
        acc_installer = session.env['account.installer'].create({
            'charts': 'l10n_fr',
            'company_id': session.env.ref('base.main_company').id,
            'date_start': account_start_date,
            'date_stop': account_end_date,
            'period': account_period,
        })
        acc_installer.execute()
        account_installer_todo.write({'state': 'done'})

    account_chart_todo = session.env.ref(
        'account.action_wizard_multi_chart_todo'
    )
    if account_chart_todo.state == 'open':
        acc_chart_wizard = session.env['wizard.multi.charts.accounts'].create({
            'chart_template_id': session.env.ref('l10n_fr.l10n_fr_pcg_chart_template').id,
            'company_id': session.env.ref('base.main_company').id,
            'sale_tax': session.env.ref('l10n_fr.tva_reduite').id,
            'purchase_tax': session.env.ref('l10n_fr.tva_acq_reduite').id,
            'currency_id': session.env.ref('base.EUR').id,
            'code_digits': 6,
        })
        acc_chart_wizard.execute()
        account_chart_todo.write({'state': 'done'})
