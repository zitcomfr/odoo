# -*- coding: utf-8 -*-
{
    'name': 'Fraichement Bon',
    'version': '0.1',
    'sequence': 150,
    'category': 'custom',
    'author': 'Anybox',
    'website': 'http://anybox.fr',
    'depends': [
        'base',
        'product',
        'account_accountant',
        'sale',
        'web_barcode_reader',
        'report_custom_filename',
    ],
    'data': [
        'data/disable_mail_server.xml',
        'data/users.xml',
        'data/company.xml',
        'data/partners.xml',
        'view/sale.xml',
        'view/product.xml',
        'view/company.xml',
        'view/refund.xml',
        'security/ir.model.access.csv',
        'report/layout.xml',
        'report/sale_order.xml',
        'report/account_invoice.xml',
    ],
    'test': [
    ],
    'demo': [
        'demo/products.xml',
        'demo/customer_info.xml',
    ],
    'js': [
    ],
    'qweb': [
    ],
    'css': [
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
    'license': 'AGPL-3',
}
