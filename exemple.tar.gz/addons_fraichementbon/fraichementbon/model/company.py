# -*- coding: utf-8 -*-
from openerp import api, models, fields


class Company(models.Model):
    _inherit = 'res.partner'

    _sql_constraints = [('ref_unique', 'UNIQUE(ref)',
                         "Le code du client doit etre unique !")]

    default_margin = fields.Float(
        string="Marge par défaut (%)", required=True, default=0.0
    )

    @api.model
    def name_search(self, name='', args=None, operator='ilike', limit=100):
        if not args:
            args = []
        domain = []
        if self.env['res.partner'].check_ref(name):
            domain = [('ref', '=', name)]
            res = self.search(domain, limit=limit)
            if res:
                return res.name_get()
        return super(Company, self).name_search(
            name=name,
            args=args,
            operator=operator,
            limit=limit)

    def check_ref(self, ref):
        """Determine whether the parameter may be a company's reference"""
        if len(ref) == 4:
            return True
        return False
