# -*- coding: utf-8 -*-
from openerp import api
from openerp import exceptions
from openerp import fields
from openerp import models


class Sale(models.Model):
    _name = 'sale.order'
    _inherit = [
        'sale.order',
        "abstract.naming",
    ]

    sale_order_line_report_ids = fields.One2many(
        'sale.order.line.report', 'sale_id', 'Aggregate sale order lines'
    )

    @api.multi
    def barcode_read(self, barcode):
        self.ensure_one()
        sale_order_line = self.env['sale.order.line']
        sale_order_line.create(self.prepare_sale_order_line_data(
            barcode, self))
        return True

    def prepare_sale_order_line_data(self, barcode, sale_record):
        product = self.env['product.product'].get_product(barcode)
        (indicative_number, product_ref, data) = self.env[
            'product.product'].interpret_ean13(barcode)

        price = product.list_price
        weight = 1.0
        if indicative_number == '22':
            price = self.env['product.product'].get_price_from_ean(barcode)
        else:
            weight = self.env['product.product'].get_weight_from_ean(barcode)

        if len(product.taxes_id) == 0:
            raise exceptions.ValidationError("Aucune taxe sur le produit !")

        taxes = []
        taxes_id = []
        for tax in product.taxes_id:
            taxes.append(tax.amount)
            taxes_id.append(tax.id)

        margin = sale_record.partner_id.default_margin
        for customer_i in product.customer_info:
            if customer_i.partner_id == sale_record.partner_id:
                margin = customer_i.margin
                continue

        if indicative_number == '22':
            price = self.env['product.product'].get_price_without_taxes(
                price, taxes, margin)
        else:
            # TODO: make sure unit of price at the moment assuming €/g
            price = price * weight

        res = self.env['sale.order.line'].product_id_change(
            sale_record.pricelist_id.id,
            product.id,
            1,
            partner_id=sale_record.partner_id.id,
            fiscal_position=sale_record.fiscal_position.id
        )

        res['value'].update({
            'order_id': sale_record.id,
            'product_id': product.id,
            'name': product.name,
            'product_uom_qty': 1,
            'sequence': -1,
            'price_unit': price,
            'tax_id': [(6, 0, taxes_id)],
            'th_weight': weight
        })
        return res['value']

    @api.model
    def create(self, values):
        if values.get('name', '/') == '/':
            values.update(
                self._set_fbon_name(values.get('partner_id', False), 'BL')
            )
        return super(Sale, self).create(values)

    @api.multi
    def write(self, values):
        if values.get('partner_id'):
            self.ensure_one()
            partner = self.env['res.partner'].browse(
                values.get('partner_id', False)
            )
            self_company = self.partner_id
            if self.partner_id.parent_id:
                self_company = self.partner_id.parent_id
            company = partner.parent_id if partner.parent_id else partner
            if self_company != company:
                values.update(
                    self._set_fbon_name(values.get('partner_id', False), 'BL')
                )
        return super(Sale, self).write(values)

    @api.multi
    def get_filename(self):
        filename = 'Devis'
        if len(self) > 1:
            if self[0].state not in ['draft', 'cancel']:
                filename = 'Commandes'
        else:
            filename = self.name
        filename += '.pdf'
        return filename
