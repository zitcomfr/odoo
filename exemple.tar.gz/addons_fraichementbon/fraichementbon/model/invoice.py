# -*- coding: utf-8 -*-
from openerp import api, fields
from openerp import models
from openerp import tools
from openerp.addons import decimal_precision as dp
from openerp.exceptions import except_orm
from openerp.tools.translate import _


class Invoice(models.Model):
    _name = 'account.invoice'
    _inherit = [
        'account.invoice',
    ]

    invoice_line_report_ids = fields.One2many(
        'account.invoice.line.report', 'invoice_id', 'Aggregate invoice lines'
    )

    @api.multi
    def get_filename(self):
        types = {
            'in_invoice': '_get_in_invoice_filename',
            'in_refund': '_get_in_refund_filename',
            'out_invoice': '_get_out_invoice_filename',
            'out_refund': '_get_out_refund_filename',
        }
        return getattr(self, types[self[0].type])()

    @api.multi
    def _get_in_invoice_filename(self):
        return self._get_filename("Facture fournisseur", 'female', False)

    @api.multi
    def _get_in_refund_filename(self):
        return self._get_filename("Avoir fournisseur", 'male', False)
        pass

    @api.multi
    def _get_out_invoice_filename(self):
        return self._get_filename("Facture", 'female', True)

    @api.multi
    def _get_out_refund_filename(self):
        return self._get_filename("Avoir", 'male', True)

    @api.multi
    def _get_filename(self, filename, gender, internal_number):
        if len(self) > 1:
            filename = filename.replace(" ", "s ")
            filename += "s"
        else:
            names = {'draft': u"brouillon", 'cancel': u"annulé"}
            if self.state in names.keys():
                filename += "_%s" % names[self.state]
                if gender == 'female' and self.state == 'cancel':
                    filename += u'e'
            else:
                if internal_number:
                    filename = "%s" % self.number
                else:
                    filename += "_%s" % self.number.replace('/', '-')
        filename += ".pdf"
        return filename


class AccountMove(models.Model):
    _name = 'account.move'
    _inherit = [
        'account.move',
        'abstract.naming',
    ]

    def post(self, cr, uid, ids, context=None):
        """Overwrite the post method to manage name of the invoice differently

        """
        if context is None:
            context = {}
        invoice = context.get('invoice', False)
        valid_moves = self.validate(cr, uid, ids, context)

        if not valid_moves:
            raise except_orm(
                _('Error!'),
                _(
                    'You cannot validate a non-balanced entry.\nMake sure you '
                    'have configured payment terms properly.\nThe latest '
                    'payment term line should be of the "Balance" type.'
                )
            )
        obj_sequence = self.pool.get('ir.sequence')
        for move in self.browse(cr, uid, valid_moves, context=context):
            if move.name == '/':
                # PV: Start editing, do not use sequence on journal if move
                # is linked to an invoice or a refund
                type_name_mapping = {
                    'out_invoice': 'FA',
                    'out_refund': 'A',
                }
                journal = move.journal_id
                values = {}

                if invoice and invoice.internal_number:
                    values['name'] = invoice.internal_number
                else:
                    if invoice and invoice.type in type_name_mapping.keys():
                        values.update(
                            self._set_fbon_name(
                                cr, uid, invoice.partner_id,
                                type_name_mapping[invoice.type],
                                context=context
                            )
                        )
                    else:
                        if journal.sequence_id:
                            c = {
                                'fiscalyear_id': move.period_id.fiscalyear_id.id
                            }
                            values['name'] = obj_sequence.next_by_id(
                                cr, uid, journal.sequence_id.id, c
                            )
                        else:
                            raise except_orm(
                                _('Error!'),
                                _('Please define a sequence on the journal.')
                            )
                if values:
                    self.write(cr, uid, [move.id], values, context=context)
                # PV: End of change

        cr.execute(
            """
                UPDATE account_move
                    SET state=%s
                WHERE id IN %s
            """,
            ('posted', tuple(valid_moves),)
        )
        self.invalidate_cache(
            cr, uid, ['state', ], valid_moves, context=context
        )
        return True


class SaleOrderLineReport(models.Model):

    _name = 'account.invoice.line.report'
    _table = 'account_invoice_line_report'
    _description = 'Model to help generate reports, group invoice line ' \
                   'per products'
    _auto = False

    product_id = fields.Many2one('product.product', string=u"Product")
    invoice_id = fields.Many2one('sale.order', string=u"Invoice")
    quantity = fields.Float(
        string=u"Quantité",
        digits=dp.get_precision('Product UoS'),
    )
    price = fields.Float(
        string=u"Price without taxes",
        digits=dp.get_precision('Account')
    )

    def init(self, cr):
        tools.drop_view_if_exists(cr, self._table)

        cr.execute(
            """
            CREATE VIEW %s AS (
                SELECT
                    min(id) as id,
                    product_id,
                    invoice_id,
                    sum(quantity) as quantity,
                    sum(price_subtotal) as price
                FROM
                    account_invoice_line
                GROUP BY
                    invoice_id,
                    product_id
            )
            """ % (self._table)
        )
