# -*- coding: utf-8 -*-
from datetime import datetime

from exceptions import Warning
from openerp import api, fields, models
from openerp.tools.translate import _


class AbstractNaming(models.AbstractModel):

    _name = 'abstract.naming'
    _start_sequence = 1

    functional_sequence = fields.Integer(
        u"Functional sequence",
        help=u"The sequence number to composed the name"
    )
    sequence_criteria = fields.Char(
        u"Sequence criteria", index=True,
        help=u"Functional sequence criteria to select the next entry"
    )

    _sql_constraints = [
        (
            "Fonctionnal sequence",
            "unique(functional_sequence, sequence_criteria)",
            _(u"Functional sequence and sequence criteria must be unique")
        )
    ]

    @api.model
    def get_next_number(self, criteria):
        values = {}

        self.env.cr.execute(
            """
                SELECT
                    MAX(functional_sequence) as max
                FROM
                    %(table)s
                WHERE
                    sequence_criteria = %%s
            """ % dict(table=self._table, ),
            (criteria, )
        )
        res = self.env.cr.dictfetchall()
        sequence = self._start_sequence
        if res[0]['max']:
            sequence = res[0]['max'] + 1

        values['functional_sequence'] = sequence
        values['sequence_criteria'] = criteria
        return values

    @api.model
    def _set_fbon_name(self, partner, kind):
        if isinstance(partner, (int, long)):
            partner = self.env['res.partner'].browse(partner)
        if not partner:
            raise Warning(
                _("partner id is required to generate a new name")
            )
        if partner.parent_id:
            partner = partner.parent_id
        if not partner.ref:
            raise Warning(
                _(
                    u"You must set a reference on the partner (%s) to be able "
                    u"to generate a new name to this object"
                ) % partner.name
            )
        partial_name = "%(kind)s-%(partner_ref)s-%(date)s" % dict(
            kind=kind,
            partner_ref=partner.ref,
            date=datetime.now().strftime('%y-%m'),
        )
        values = self.get_next_number(partial_name)
        values['name'] = partial_name + "-%0.2d" % values['functional_sequence']
        return values
