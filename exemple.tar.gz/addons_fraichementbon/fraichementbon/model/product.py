# -*- coding: utf-8 -*-
from openerp import models, api, exceptions, fields, _
from openerp.addons.product import product
from openerp.tools.float_utils import float_round


class Product(models.Model):
    _inherit = 'product.product'

    _sql_constraints = [('default_code_unique', 'UNIQUE(default_code)',
                         "Le code de l'article doit etre unique !")]

    @api.model
    def name_search(self, name='', args=None, operator='ilike', limit=100):
        if not args:
            args = []
        domain = []
        if product.check_ean(name):
            try:
                (prefix, product_code, data) = self.interpret_ean13(name)
                code = prefix + product_code
                domain = [('default_code', '=', int(code))] + args
                res = self.search(domain, limit=limit)
                if res:
                    return res.name_get()
            except:
                pass
        return super(Product, self).name_search(
            name=name,
            args=args,
            operator=operator,
            limit=limit)

    def interpret_ean13(self, ean):
        """Check and interpret an ean13 code with this way :
             II AAAAA PPPPP C
             I: indicative of price or variable weight
             A: product code
             P: price or weight
             C: control key
           :param ean the ean13 code
           :return a tuple of integers
        """

        if not product.check_ean(ean):
            raise exceptions.ValidationError(_("Bad ean13 code !"))

        prefix = ean[:2]
        if (prefix != '21' and prefix != '22'):
            raise exceptions.ValidationError(
                _(u"Bad indicative number: %s for the given EAN13 %s") %
                (prefix, ean)
            )
        product_code = ean[2:7]
        price_or_weigth = ean[7:12]

        return (prefix, product_code, price_or_weigth)

    def get_product(self, ean):
        """Get an product depending of the ean13 code,
           return null if the product doesn't exist
        """
        (indicative, product_code, value) = self.interpret_ean13(ean)
        code = indicative + product_code
        product = self.env['product.product'].search(
            [('default_code', '=', int(code))]
        )
        if not product:
            raise exceptions.ValidationError(
                _(u"This product doesn't exist !  : %s") % product_code)
        return product

    def get_price_from_ean(self, ean):
        """Gets the price (euro) stored in an ean13 code"""
        (indicative, product_code, price) = self.interpret_ean13(ean)
        return self.convert_price(float(price))

    def get_weight_from_ean(self, ean):
        """Gets the weight stored in an ean13 code"""
        (indicative, product_code, weight) = self.interpret_ean13(ean)
        return float(weight)

    def get_price_without_taxes(self, price_with_tax, taxes, margin):
        """Gets the price without taxes and the margin
        param price_with_tax: price (euros)
        param taxes: list of tax
        param margin: % of margin
        """
        sum_taxes = 0
        for tax in taxes:
            sum_taxes = sum_taxes + tax
        res = (price_with_tax / (1 + sum_taxes)) / (1 + margin)
        precision = self.env['decimal.precision'].precision_get('Product Price')
        return float_round(res, precision)

    def convert_price(self, price):
        """ Convert a price FR (centimes) -> EURO """
        precision = self.env['decimal.precision'].precision_get('Product Price')
        return float_round((int(price) / 6.55957) / 100, precision)


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    customer_info = fields.One2many('product.customerinfo',
                                    'product_template_id')


class CustomerInfo(models.Model):
    _name = 'product.customerinfo'

    partner_id = fields.Many2one(
        'res.partner', ondelete='cascade', string="Revendeur", required=True
    )
    margin = fields.Float(string="Marge (%)", required=True)
    product_template_id = fields.Many2one(
        'product.template', ondelete='cascade'
    )
