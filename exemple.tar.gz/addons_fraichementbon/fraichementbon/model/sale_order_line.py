# -*- coding: utf-8 -*-
from openerp import api
from openerp import models


class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    @api.multi
    def tax_line(self):
        """Return as invoice.tax_line for a given sets of sale order line
        details of taxes. A list of tuple like
        [(tax_name, base_price, amount_of_tax), (), ...]

        """
        res = {}
        for line in self:
            line_taxes = line.tax_id.compute_all(
                line._wrapper_calc_line_base_price(),
                line._wrapper_calc_line_quantity(),
                product=line.product_id,
                partner=line.order_id.partner_id
            )
            for tax in line_taxes['taxes']:
                if tax['id'] not in res.keys():
                    res[tax['id']] = {
                        'base': 0,
                        'amount': 0,
                        'name': tax['name'],
                    }
                res[tax['id']]['amount'] += tax['amount']
                res[tax['id']]['base'] += tax['price_unit']
        for vat in res.itervalues():
            vat['amount'] = round(
                vat['amount'],
                self.env['decimal.precision'].precision_get('Product Price')
            )
        return sorted(
            [tax for tax in res.itervalues()],
            key=lambda k: k['name']
        )

    @api.v8
    def _wrapper_calc_line_base_price(self):
        return self._calc_line_base_price(self)

    @api.v8
    def _wrapper_calc_line_quantity(self):
        return self._calc_line_quantity(self)
