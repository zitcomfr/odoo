# -*- coding: utf-8 -*-
from openerp import fields
from openerp import models
from openerp.addons import decimal_precision as dp
from openerp import tools


class SaleOrderLineReport(models.Model):

    _name = 'sale.order.line.report'
    _table = 'sale_order_line_report'
    _description = 'Model to help generate reports, group sale order line ' \
                   'per products'
    _auto = False

    product_id = fields.Many2one('product.product', string=u"Product")
    sale_id = fields.Many2one('sale.order', string=u"Sale order")
    quantity = fields.Float(
        string=u"Quantité",
        digits=dp.get_precision('Product UoS'),
    )
    price = fields.Float(
        string=u"Price without taxes",
        digits=dp.get_precision('Account')
    )

    def init(self, cr):
        tools.drop_view_if_exists(cr, self._table)

        cr.execute(
            """
            CREATE VIEW sale_order_line_report AS (
                SELECT
                    min(sol.id) as id,
                    sol.order_id as sale_id, sol.product_id,
                    sum(product_uom_qty) as quantity,
                    sum(product_uom_qty * price_unit) as price
                FROM
                    sale_order_line sol
                GROUP BY
                    sol.order_id,
                    sol.product_id
            )
            """
        )
