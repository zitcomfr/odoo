# -*- coding: utf-8 -*-
from openerp import models, fields, api
from openerp import exceptions


class RefundWizard(models.TransientModel):
    _name = 'fb.wizard_refunds'

    state = fields.Selection([('stage_1', 'Etape 1'),
                              ('stage_2', 'Etape 2')],
                             default='stage_1')

    data = fields.Text(string="Données", required=True)
    refunds_list = fields.One2many('fb.wizard_refund_line', 'wizard_id')

    @api.multi
    def action_compile_data(self):
        """Action called from wizard view view/refund.xml
        For each company's code, we create a refund with the products
        (list of ean13 codes) associated to this company
        """
        if not self.data or not (len(self.data) > 0):
            raise exceptions.ValidationError(u"Aucune données !")

        res = self.compile_data(self.data)

        lines = []
        for (company_ref, ean_list) in res:
            company = self.env['res.partner'].search(
                [('ref', '=', company_ref)], limit=1
            )
            for ean in ean_list:
                try:
                    product = self.env['product.product'].get_product(ean)
                except:
                    product = None
                    pass

                taxes = []
                if product:
                    for tax in product.taxes_id:
                        taxes.append(tax.amount)

                margin = 0.0
                if company:
                    margin = company.default_margin
                    if company and product:
                        for c in product.customer_info:
                            if c.partner_id.id == company.id:
                                margin = c.margin
                                continue

                price = self.env['product.product'].get_price_from_ean(ean)
                price = self.env['product.product'].get_price_without_taxes(
                    price, taxes, margin
                )

                dic = {}
                dic['ean_code'] = ean
                if company:
                    dic['company'] = company.id
                if product:
                    dic['product'] = product.id
                dic['margin'] = margin
                dic['price'] = price
                lines.append((0, 0, dic))
        self.refunds_list = lines

        self.state = 'stage_2'
        return {'type': 'ir.actions.act_window',
                'view_type': 'form',
                'view_mode': 'form',
                'res_model': 'fb.wizard_refunds',
                'res_id': self.id,
                'target': 'new'
                }

    @api.multi
    def action_save_data(self):
        """Action available on stage 2, we create the refunds and open a
           tree view
        """
        refunds = {}
        refunds_data = []
        refund_ids = []
        for re_line in self.refunds_list:
            if not re_line.check_data():
                raise exceptions.ValidationError(
                    "Vous devez remplir tous les champs !"
                )
            if re_line.company.id not in refunds:
                refunds[re_line.company.id] = []
            refunds[re_line.company.id].append(re_line)

        for company_id, refund_lines in refunds.items():
            products = []
            for refund_line in refund_lines:
                dic = self.env['account.invoice.line'].product_id_change(
                    product=refund_line.product.id,
                    uom_id=self.env.ref('product.product_uom_unit').id,
                    qty=1,
                    type='out_refund',
                    partner_id=company_id,
                    price_unit=refund_line.price)
                tax_ids = []
                for i in refund_line.product.taxes_id:
                    tax_ids.append(i.id)
                name = refund_line.product.name
                if refund_line.product.description:
                    name = refund_line.product.description
                if refund_line.product.description_sale:
                    name = refund_line.product.description_sale

                dic['value'].update({'product_id': refund_line.product.id,
                                     'name': name,
                                     'price_unit': refund_line.price,
                                     'invoice_line_tax_id': [(6, 0, tax_ids)]
                                     })
                products.append((0, 0, dic['value']))

            res = self.env['account.invoice'].onchange_partner_id(
                type='out_refund',
                partner_id=company_id,
                date_invoice=fields.Date.today()
            )

            res['value'].update({'partner_id': company_id,
                                 'invoice_line': products,
                                 'type': 'out_refund',
                                 'date_invoice': fields.Date.today()})
            refunds_data.append(res['value'])
        # PV: move refund creation outide of the above loops as a strange
        # behavior on unit test only where refund_lines empty record after
        # the first refund creation
        for refund_data in refunds_data:
            refund = self.env['account.invoice'].create(refund_data)
            refund_ids.append(refund.id)
            refund.button_reset_taxes()

        return {'type': 'ir.actions.act_window',
                'view_type': 'form',
                'view_mode': 'tree,form,calendar,graph',
                'res_model': 'account.invoice',
                'domain': [
                    ('id', 'in', refund_ids),
                    ('type', '=', 'out_refund')
                ],
                'context': {'default_type': 'out_refund',
                            'type': 'out_refund',
                            'journal_type': 'sale',
                            'form_view_ref': 'account.invoice_form'},
                }

    @api.multi
    def action_cancel(self):
        """Action available on stage 2: we come back on stage 1"""
        for r in self.refunds_list:
            r.unlink()
        self.state = 'stage_1'
        return {'type': 'ir.actions.act_window',
                'view_type': 'form',
                'view_mode': 'form',
                'res_model': 'fb.wizard_refunds',
                'res_id': self.id,
                'target': 'new'
                }

    def compile_data(self, data):
        """Create a list of tuple (company_code, list of ean13 codes)
           from the param data
        """
        res = []
        current_code = None
        current_list_ean = []

        lines = data.split('\n')
        for line in lines:
            line_size = len(line)
            if line_size == 4:
                if len(current_list_ean) > 0 and current_code is not None:
                    res.append((current_code, current_list_ean))
                    current_list_ean = []
                    current_code = None
                current_code = line
            elif line_size == 13:
                if current_code is None:
                    raise exceptions.ValidationError(
                        u"Erreur dans le format des données !\n"
                        u"Définir un code client avant le code produit %s" %
                        line
                    )
                current_list_ean.append(line)
            elif line_size != 0:
                raise exceptions.ValidationError(
                    u"Erreur dans le format des données !\n Ligne : %s" % line
                )
        if len(current_list_ean) > 0 and current_code is not None:
            res.append((current_code, current_list_ean))
        return res


class RefundLine(models.TransientModel):
    _name = 'fb.wizard_refund_line'

    wizard_id = fields.Many2one('fb.wizard_refunds')

    ean_code = fields.Char(string="Code barre", readonly=True)
    company = fields.Many2one('res.partner', string="Client")
    product = fields.Many2one('product.product', string="Produit")
    margin = fields.Float(string="Margin")
    price = fields.Float(string="Prix HT")

    @api.multi
    def check_data(self):
        self.ensure_one()
        return self.company.id and self.product.id and True

    @api.onchange('company', 'product')
    def _update_data(self):
        if self.company:
            self.margin = self.company.default_margin
        if self.company and self.product:
            for c in self.product.customer_info:
                if c.partner_id.id == self.company.id:
                    self.margin = c.margin
                    continue
        taxes = []
        if self.product:
            for tax in self.product.taxes_id:
                taxes.append(tax.amount)
        if self.ean_code:
            price = self.env['product.product'].get_price_from_ean(
                self.ean_code
            )
            self.price = self.env['product.product'].get_price_without_taxes(
                price, taxes, self.margin
            )

    @api.onchange('margin')
    def _update_margin(self):
        taxes = []
        if self.product:
            for tax in self.product.taxes_id:
                taxes.append(tax.amount)
        if self.ean_code:
            price = self.env['product.product'].get_price_from_ean(
                self.ean_code
            )
            self.price = self.env['product.product'].get_price_without_taxes(
                price, taxes, self.margin
            )
