# -*- coding: utf-8 -*-
from . import model  # noqa
