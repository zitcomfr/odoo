# -*- coding: utf-8 -*-
from .fbon_testcase import FraichementBonTransactionCase
from datetime import datetime
from exceptions import Warning


class NamingNomenclatureBase(FraichementBonTransactionCase):

    def setUp(self):
        super(NamingNomenclatureBase, self).setUp()
        self.customer = self.env['res.partner'].create(
            {
                'name': "A Company",
                "ref": "4444",
                "customer": True,
                "is_company": True,
            }
        )
        self.contact_4444 = self.env['res.partner'].create(
            {
                'name': "A Company contact",
                'parent_id': self.customer.id,
            }
        )
        self.customer_6666 = self.env['res.partner'].create(
            {
                'name': "Another Company",
                "ref": "6666",
                "customer": True,
                "is_company": True,
            }
        )
        self.contact_6666 = self.env['res.partner'].create(
            {
                'name': "A Company contact",
                'parent_id': self.customer_6666.id,
            }
        )


class SoNaming(NamingNomenclatureBase):

    def test_missing_partner(self):
        with self.assertRaises(Warning):
            self.env['sale.order'].create({})

    def test_so_naming(self):
        sale = self.create_so(partner_id=self.customer.id)
        self.assertEqual(
            "BL-4444-16-09-01",
            sale.name
        )
        sale = self.create_so(partner_id=self.customer.id)
        self.assertEqual(
            "BL-4444-16-09-02",
            sale.name
        )
        datetime.set_now(datetime(2016, 10, 01, 15, 57, 0))
        sale = self.create_so(partner_id=self.customer.id)
        self.assertEqual(
            "BL-4444-16-10-01",
            sale.name
        )

    def test_change_company(self):
        sale1 = self.create_so(partner_id=self.customer_6666.id)
        sale2 = self.create_so(partner_id=self.customer.id)
        self.assertEqual(
            "BL-6666-16-09-01",
            sale1.name
        )
        self.assertEqual(
            "BL-4444-16-09-01",
            sale2.name
        )
        sale2.partner_id = self.customer_6666
        self.assertEqual(
            "BL-6666-16-09-02",
            sale2.name
        )
        sale3 = self.create_so(partner_id=self.customer.id)
        self.assertEqual(
            "BL-4444-16-09-01",
            sale3.name
        )
        sale3.partner_id = self.contact_4444
        self.assertEqual(
            "BL-4444-16-09-01",
            sale3.name
        )
        sale3.partner_id = self.contact_6666
        self.assertEqual(
            "BL-6666-16-09-03",
            sale3.name
        )

    def test_linked_person(self):
        sale1 = self.create_so(partner_id=self.contact_6666.id)
        self.assertEqual(
            "BL-6666-16-09-01",
            sale1.name
        )


class InvoiceNaming(NamingNomenclatureBase):

    def test_invoice_name(self):
        invoice = self.create_invoice(partner_id=self.customer_6666.id)
        self.assertEqual(
            'FA-6666-16-09-01',
            invoice.number
        )
        invoice = self.create_invoice(partner_id=self.contact_6666.id)
        self.assertEqual(
            'FA-6666-16-09-02',
            invoice.number
        )
        datetime.set_now(datetime(2016, 10, 01, 15, 57, 0))
        invoice = self.create_invoice(partner_id=self.customer_6666.id)
        self.assertEqual(
            'FA-6666-16-10-01',
            invoice.number
        )


class RefundNaming(NamingNomenclatureBase):

    def test_refund_name(self):
        refund = self.create_refund(
            data="4444\n2248870026197\n2248857010003\n2248870026197\n"
        )
        refund.ensure_one()
        self.assertEqual(
            'A-4444-16-09-01',
            refund.number
        )
        refund = self.create_refund(
            data="4444\n2248870026197\n2248857010003\n2248870026197\n"
        )
        refund.ensure_one()
        self.assertEqual(
            'A-4444-16-09-02',
            refund.number
        )
        datetime.set_now(datetime(2016, 10, 01, 15, 57, 0))
        refund = self.create_refund(
            data="4444\n2248870026197\n2248857010003\n2248870026197\n"
        )
        refund.ensure_one()
        self.assertEqual(
            'A-4444-16-10-01',
            refund.number
        )
        refund = self.create_refund(
            data="6666\n2248870026197\n2248857010003\n2248870026197\n"
        )
        refund.ensure_one()
        self.assertEqual(
            'A-6666-16-10-01',
            refund.number
        )

    def test_multiple_refunds(self):
        refunds = self.create_refund(
            data="4444\n2248870026197\n2248857010003\n2248870026197\n"
                 "6666\n2248870026197\n2248857010003\n2248870026197\n"
        )
        self.assertEqual(
            [u'A-4444-16-09-01', u'A-6666-16-09-01'],
            sorted([refund.number for refund in refunds])
        )

    def test_invoice_refund_one_customer(self):
        invoice = self.create_invoice(partner_id=self.customer.id)
        self.assertEqual(
            'FA-4444-16-09-01',
            invoice.number
        )
        refund = self.create_refund(
            data="4444\n2248870026197\n2248857010003\n2248870026197\n"
        )
        refund.ensure_one()
        self.assertEqual(
            'A-4444-16-09-01',
            refund.number
        )
        invoice = self.create_invoice(partner_id=self.customer.id)
        self.assertEqual(
            'FA-4444-16-09-02',
            invoice.number
        )
        refund = self.create_refund(
            data="4444\n2248870026197\n2248857010003\n2248870026197\n"
        )
        refund.ensure_one()
        self.assertEqual(
            'A-4444-16-09-02',
            refund.number
        )
