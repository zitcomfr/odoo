# -*- coding: utf-8 -*-
from openerp.tests.common import TransactionCase
from openerp import exceptions


class TestCompany(TransactionCase):

    def test_check_ref(self):
        self.assertEqual(self.env['res.partner'].check_ref('6815'),
                         True)

    def test_check_bad_ref(self):
        self.assertEqual(self.env['res.partner'].check_ref('11'),
                         False)

    def test_name_search(self):
        res = self.env['res.partner'].name_search('6815', limit=1)
        (res_id, res_name) = res[0]
        company = self.env['res.partner'].search(
            [('ref', '=', '6815')], limit=1
        )
        if not company:
            raise exceptions.ValidationError("A company is missing !")
        self.assertEqual(res_name, company.name)

    def test_name_search_without_args(self):
        res = self.env['res.partner'].name_search('6815', args=None, limit=1)
        (res_id, res_name) = res[0]
        company = self.env['res.partner'].search(
            [('ref', '=', '6815')], limit=1
        )
        if not company:
            raise exceptions.ValidationError("A company is missing !")
        self.assertEqual(res_name, company.name)

    def test_name_search_by_name(self):
        res = self.env['res.partner'].name_search('PAD')
        if not res:
            raise exceptions.ValidationError("The PAD company is missing !")
        (res_id, res_name) = res[0]
        company = self.env['res.partner'].browse(res_id)
        self.assertEqual(company.ref, '5017')

    def test_bad_name_search(self):
        res = self.env['res.partner'].name_search('0000')
        self.assertEqual(res, [])
