# -*- coding: utf-8 -*-
import os
from .fbon_testcase import FraichementBonTransactionCase


class TestInvoiceReport(FraichementBonTransactionCase):

    def setUp(self):
        super(TestInvoiceReport, self).setUp()
        self.create_invoice(order={'name': "123"})

    def test_simple_invoice_report(self):
        # Report must be predicatable by default both sequence has 10
        if (
            self.sale.invoice_ids.tax_line[0].tax_code_id ==
            self.shaker.taxes_id.tax_code_id
        ):
            self.sale.invoice_ids.tax_line[1].sequence = 1
        else:
            self.sale.invoice_ids.tax_line[0].sequence = 1

        self.assertOdooReport(
            os.path.join(
                os.path.dirname(__file__),
                'expected_reports',
                'test_simple_invoice_report.pdf'
            ),
            'account.invoice',
            'account.report_invoice',
            [self.sale.invoice_ids.id],
            data={},
            context=None
        )

    def test_account_invoice_line_report(self):
        self.assertEqual(
            sum([
                line.price for line in
                self.sale.invoice_ids.invoice_line_report_ids
            ]),
            21.69
        )
