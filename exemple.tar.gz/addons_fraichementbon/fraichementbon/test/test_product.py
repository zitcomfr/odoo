# -*- coding: utf-8 -*-
from openerp.tests.common import TransactionCase
from openerp import exceptions


class TestProduct(TransactionCase):

    def test_interpret_ean(self):
        self.assertEqual(
            self.env['product.product'].interpret_ean13("2248857022969"),
            ('22', '48857', '02296'))

    def test_get_product(self):
        prod = self.env['product.product'].get_product("2248857022969")
        if prod:
            self.assertEqual('2248857', prod.default_code)
        else:
            self.fail("Expected product not found.")

    def test_product_by_name(self):
        prod = self.env['product.product'].name_search("Shaker")
        if prod:
            self.assertNotEqual(len(prod), 0)
        else:
            self.fail("Expected product not found.")

    def test_bad_product_code(self):
        with self.assertRaises(exceptions.ValidationError):
            self.env['product.product'].get_product("2199999999995")

    def test_ean_too_small(self):
        with self.assertRaises(exceptions.ValidationError):
            self.env['product.product'].interpret_ean13("21971000000")

    def test_bad_indicative(self):
        with self.assertRaises(exceptions.ValidationError):
            self.env['product.product'].interpret_ean13("1200000000003")

    def test_bad_checksum(self):
        with self.assertRaises(exceptions.ValidationError):
            self.env['product.product'].interpret_ean13("2197100000012")

    def test_good_name_search(self):
        product = self.env['product.product'].name_search("2248857022969")
        (prod_id, prod_name) = product[0]
        prod = self.env['product.product'].browse(prod_id)
        self.assertEqual(prod.default_code, '2248857')

    def test_bad_name_search(self):
        prod = self.env['product.product'].name_search("2199999999995")
        self.assertEqual(prod, [])

    def test_bad_ean_name_search(self):
        products = self.env['product.product'].name_search("2197100000019")
        self.assertNotEqual(len(products), 1)

    def test_name_search_without_args(self):
        product = self.env['product.product'].name_search(
            "2248857022969", args=None
        )
        (prod_id, prod_name) = product[0]
        prod = self.env['product.product'].browse(prod_id)
        self.assertEqual(prod.default_code, '2248857')

    def test_name_search_unknown_product(self):
        product = self.env['product.product'].name_search("2197100000011")
        self.assertEqual(len(product), 0)

    def test_convert_price(self):
        (prefix, product_code, price) = self.env['product.product'].\
            interpret_ean13('2248857022969')
        new_price = self.env['product.product'].convert_price(price)
        self.assertEqual(new_price, 3.50)

    def test_get_price_from_ean(self):
        price = self.env['product.product'].get_price_from_ean(
            '2248857022969'
        )
        self.assertEqual(price, 3.50)

    def test_get_price_without_taxes(self):
        price = self.env['product.product'].get_price_without_taxes(
            3.5, [0.1], 0
        )
        self.assertEqual(price, 3.18)

    def test_get_weight_from_ean(self):
        weight = self.env['product.product'].get_weight_from_ean(
            '2148857022962'
        )
        self.assertEqual(weight, 2296.00)
