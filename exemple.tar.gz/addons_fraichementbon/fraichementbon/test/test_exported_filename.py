# -*- coding: utf-8 -*-
from .fbon_testcase import FraichementBonTransactionCase


class TestSaleFileNames(FraichementBonTransactionCase):

    def test_quotation_filename(self):
        sale = self.create_so()
        self.assertEqual(
            "BL-6815-16-09-01.pdf",
            sale.get_filename()
        )
        sale.signal_workflow('cancel')
        self.assertEqual(
            "BL-6815-16-09-01.pdf",
            sale.get_filename()
        )

    def test_multiple_quotations_filename(self):
        orders = self.env['sale.order'].search(
            [('state', 'in', ['cancel', 'draft'])]
        )
        self.assertTrue(len(orders) > 1)
        self.assertEqual(
            "Devis.pdf",
            orders.get_filename()
        )
        orders = self.env['sale.order'].search(
            [('state', 'not in',  ['cancel', 'draft'])]
        )
        self.assertTrue(len(orders) > 1)
        self.assertEqual(
            "Commandes.pdf",
            orders.get_filename()
        )

    def test_order_filename(self):
        sale = self.create_so()
        sale.signal_workflow('order_confirm')
        self.assertEqual(
            "BL-6815-16-09-01.pdf",
            sale.get_filename()
        )


class TestInoiveFilesName(FraichementBonTransactionCase):

    def invoice_factory(self, invoice_type):
        invoice_data = self.env['account.invoice'].onchange_partner_id(
            type=invoice_type,
            partner_id=self.ref('fraichementbon.res_partner_magodis'),
        )['value']

        invoice_data.update(
            {
                'partner_id': self.ref('fraichementbon.res_partner_magodis'),
                'type': invoice_type,
            }
        )
        invoice = self.env['account.invoice'].create(
            invoice_data
        )
        invoice_line_data = self.env['account.invoice.line'].product_id_change(
            product=self.ananas.id,
            uom_id=self.env.ref('product.product_uom_unit').id,
            qty=1,
            type=invoice_type,
            partner_id=self.ref('fraichementbon.res_partner_magodis'),
            price_unit=12,
        )['value']
        tax_ids = [tax.id for tax in self.ananas.taxes_id]

        invoice_line_data.update(
            {
                'invoice_id': invoice.id,
                'product_id': self.ananas.id,
                'name': "ananas",
                'invoice_line_tax_id': [(6, 0, tax_ids)],
                'price_unit': 12,
            }
        )
        self.env['account.invoice.line'].create(
            invoice_line_data
        )
        return invoice

    def test_draft_in_invoice_filename(self):
        purchase_invoice = self.invoice_factory('in_invoice')
        self.assertEqual(
            purchase_invoice.get_filename(),
            "Facture fournisseur_brouillon.pdf"
        )

    def test_validate_in_invoice_filename(self):
        purchase_invoice = self.invoice_factory('in_invoice')
        purchase_invoice.signal_workflow('invoice_open')
        self.assertEqual(
            purchase_invoice.get_filename(),
            "Facture fournisseur_SAJ-2016-0001.pdf"
        )

    def test_cancelled_in_invoice_filename(self):
        purchase_invoice = self.invoice_factory('in_invoice')
        purchase_invoice.signal_workflow('invoice_cancel')
        self.assertEqual(
            purchase_invoice.get_filename(),
            u"Facture fournisseur_annulée.pdf"
        )

    def test_draft_out_invoice_filename(self):
        invoice = self.create_invoice(open_invoice=False)
        self.assertEqual(
            "Facture_brouillon.pdf",
            invoice.get_filename()
        )

    def test_validate_out_invoice_filename(self):
        invoice = self.create_invoice()
        self.assertEqual(
            "FA-6815-16-09-01.pdf",
            invoice.get_filename()
        )

    def test_cancelled_out_invoice_filename(self):
        invoice = self.create_invoice(open_invoice=False)
        invoice.signal_workflow('invoice_cancel')
        self.assertEqual(
            u"Facture_annulée.pdf",
            invoice.get_filename()
        )

    def test_draft_in_refund_filename(self):
        supplier_refund = self.invoice_factory('in_refund')
        self.assertEqual(
            supplier_refund.get_filename(),
            "Avoir fournisseur_brouillon.pdf"
        )

    def test_validate_in_refund_filename(self):
        supplier_refund = self.invoice_factory('in_refund')
        supplier_refund.signal_workflow('invoice_open')
        self.assertEqual(
            supplier_refund.get_filename(),
            "Avoir fournisseur_SAJ-2016-0001.pdf"
        )

    def test_cancelled_in_refund_filename(self):
        supplier_refund = self.invoice_factory('in_refund')
        supplier_refund.signal_workflow('invoice_cancel')
        self.assertEqual(
            supplier_refund.get_filename(),
            u"Avoir fournisseur_annulé.pdf"
        )

    def test_draft_out_refund_filename(self):
        refund = self.create_refund(
            open_refund=False,
            data="6815\n2248857022969\n2248870025206\n2248870026210\n"
        )
        self.assertEqual(
            "Avoir_brouillon.pdf",
            refund.get_filename()
        )

    def test_validate_out_refund_filename(self):
        refund = self.create_refund(
            data="6815\n2248857022969\n2248870025206\n2248870026210\n"
        )
        self.assertEqual(
            "A-6815-16-09-01.pdf",
            refund.get_filename()
        )

    def test_cancelled_out_refund_filename(self):
        refund = self.create_refund(
            open_refund=False,
            data="6815\n2248857022969\n2248870025206\n2248870026210\n"
        )
        refund.signal_workflow('invoice_cancel')
        self.assertEqual(
            u"Avoir_annulé.pdf",
            refund.get_filename()
        )

    def test_multiple_out_invoices_filename(self):
        invoices = self.env['account.invoice'].search(
            [('type', '=', 'out_invoice')]
        )
        self.assertEqual(
            "Factures.pdf",
            invoices.get_filename()
        )

    def test_multiple_out_refunds_filename(self):
        refunds = self.create_refund(
            open_refund=False,
        )
        refunds.signal_workflow('invoice_cancel')
        self.assertEqual(
            "Avoirs.pdf",
            refunds.get_filename()
        )

    def test_multiple_in_invoices_filename(self):
        invoices = self.env['account.invoice'].search(
            [('type', '=', 'in_invoice')]
        )
        self.assertEqual(
            "Factures fournisseurs.pdf",
            invoices.get_filename()
        )

    def test_multiple_in_refunds_filename(self):
        self.invoice_factory('in_refund')
        self.invoice_factory('in_refund')
        refunds = self.env['account.invoice'].search(
            [
                ('state', '=', 'draft'),
                ('type', '=', 'in_refund'),
            ]
        )
        refunds.signal_workflow('invoice_cancel')
        self.assertEqual(
            "Avoirs fournisseurs.pdf",
            refunds.get_filename()
        )
