# -*- coding: utf-8 -*-
from anybox.testing.openerp import TransactionCase
import anybox.testing.datetime  # noqa
from datetime import datetime


class FraichementBonTransactionCase(TransactionCase):

    _user = 'fraichementbon.user_lfiscal'

    def setUp(self):
        super(FraichementBonTransactionCase, self).setUp()
        self.ananas = self.env.ref('fraichementbon.product_ananas_morceaux')
        self.shaker = self.env.ref('fraichementbon.product_shaker')
        self.tva_col_reduite = self.env['account.tax'].search(
            [('description', '=', '5.5')]
        )
        self.tva_vol_intermediaire = self.env['account.tax'].search(
            [('description', '=', '10.0')]
        )
        self.tva_col_reduite.ensure_one()
        self.tva_vol_intermediaire.ensure_one()
        self.ananas.taxes_id = [(6, 0, [self.tva_col_reduite.id])]
        self.shaker.taxes_id = [(6, 0, [self.tva_vol_intermediaire.id])]
        self.env['res.company'].search([]).siret = "814 266 433"
        datetime.set_now(datetime(2016, 9, 16, 15, 57, 0))

    def get_sale_order_data(self, **kwargs):
        res = {
            'date_order': '2016-08-05T15:29:00',
            'partner_id': self.ref('fraichementbon.res_partner_magodis'),
        }
        return update_entries(res, **kwargs)

    def create_so(self, **kwargs):
        sale = self.env['sale.order'].create(
            self.get_sale_order_data(**kwargs)
        )
        # 3 shakers => 4.91€
        sale.barcode_read('2248857010003')  # 1.52€ TVA:10% marge: 8% HT:1.28€
        sale.barcode_read('2248857015008')  # 2.29€ TVA:10% marge: 8% HT:1.93€
        sale.barcode_read('2248857013257')  # 2.02€ TVA:10% marge: 8% HT:1.70€
        # 5 ananas => 16.78€
        sale.barcode_read('2248870025206')  # 3.84€ TVA: 5% marge:12% HT:3.25€
        sale.barcode_read('2248870026180')  # 3.99€ TVA: 5% marge:12% HT:3.38€
        sale.barcode_read('2248870026197')  # 3.99€ TVA: 5% marge:12% HT:3.38€
        sale.barcode_read('2248870026203')  # 3.99€ TVA: 5% marge:12% HT:3.38€
        sale.barcode_read('2248870026210')  # 4.00€ TVA: 5% marge:12% HT:3.39€
        return sale

    def create_invoice(self, open_invoice=True, **kwargs):
        self.sale = self.create_so(**kwargs)
        self.sale.signal_workflow('order_confirm')
        self.sale.signal_workflow('manual_invoice')
        invoice = self.sale.invoice_ids[0]
        if open_invoice:
            invoice.signal_workflow('invoice_open')
        return invoice

    def create_refund(self, open_refund=True, **kwargs):
        dic = {
            'data': "6815\n2248857022969\n2248870025206\n2248870026210\n"
                    "6854\n2248870026197\n2248857010003\n2248870026197\n"
        }
        update_entries(dic, **kwargs)
        wizard_refund = self.env['fb.wizard_refunds'].create(dic)
        wizard_refund.action_compile_data()
        res = wizard_refund.action_save_data()
        refunds = self.env['account.invoice'].search(res['domain'])
        if open_refund:
            refunds.signal_workflow('invoice_open')
        return refunds


def update_entries(values, **kwargs):
    if not values:
        values = {}
    if kwargs:
        values.update(**kwargs)
        entries_to_remove = [x for x, y in kwargs.items() if y is None]
        for entry_to_remove in entries_to_remove:
            del values[entry_to_remove]

    return values
