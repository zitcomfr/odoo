# -*- coding: utf-8 -*-
from openerp.tests.common import TransactionCase


class TestSale(TransactionCase):

    def setUp(self):
        super(TestSale, self).setUp()
        tax = self.env['account.tax'].search([('name', '=', 'test')])
        if not tax:
            data = {'name': 'test',
                    'sequence': 1,
                    'amount': 10,
                    'type': 'percent',
                    }
            tax = self.env['account.tax'].create(data)
        product = self.env['product.product'].search([('name', '=', 'test')])
        if not product:
            data = {'name': 'test',
                    'type': 'consu',
                    'uom_id': self.env.ref('product.product_uom_unit').id,
                    'uom_po_id': self.env.ref('product.product_uom_unit').id,
                    'default_code': '2255555',
                    'taxes_id': [(6, 0, [tax.id])],
                    }
            self.env['product.product'].create(data)

    def test_prepare_sale_order_line_data(self):
        res = self.env['sale.order'].prepare_sale_order_line_data(
            '2255555022962', self.env.ref('sale.sale_order_1'))
        self.assertEqual(res['name'], 'test')

    def test_barcode_read(self):
        sale_order = self.env.ref('sale.sale_order_1')
        sale_order.barcode_read('2255555022962')
        res = self.env['sale.order.line'].search([('name', '=', 'test')])
        self.assertEqual(len(res), 1)
