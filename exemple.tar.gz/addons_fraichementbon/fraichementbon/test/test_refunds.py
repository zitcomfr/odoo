# -*- coding: utf-8 -*-
from openerp.tests.common import TransactionCase
from openerp import exceptions


class TestRefunds(TransactionCase):

    def test_1_compile_data(self):
        data = "1111\n1234567898765\n"
        res = self.env['fb.wizard_refunds'].compile_data(data)
        expected = [('1111', ['1234567898765'])]
        self.assertEqual(res, expected)

    def test_2_compile_data(self):
        data = "1111\n1234567898765\n2222\n9876543212345\n1234567898765\n"
        res = self.env['fb.wizard_refunds'].compile_data(data)
        expected = [
            ('1111', ['1234567898765']),
            ('2222', ['9876543212345', '1234567898765'])
        ]
        self.assertEqual(res, expected)

    def test_3_compile_data(self):
        data = "1111\n123456"
        with self.assertRaises(exceptions.ValidationError):
            self.env['fb.wizard_refunds'].compile_data(data)

    def test_1_check_data(self):
        company = self.env['res.partner'].search([], limit=1)
        product = self.env['product.product'].search([], limit=1)
        dic = {'ean_code': '2248870028535',
               'company': company.id,
               'product': product.id,
               'margin': 1.0,
               'price_full_tax': 1.0}
        wizard_refund_line = self.env['fb.wizard_refund_line'].create(dic)
        self.assertEqual(wizard_refund_line.check_data(), True)

    def test_2_check_data(self):
        dic = {'ean_code': '2248870028535',
               'margin': 1.0,
               'price_full_tax': 1.0}
        wizard_refund_line = self.env['fb.wizard_refund_line'].create(dic)
        self.assertEqual(wizard_refund_line.check_data(), False)

    def test_action_cancel(self):
        dic = {'data': "6815\n2248857022969\n"}
        wizard_refund = self.env['fb.wizard_refunds'].create(dic)
        self.assertEqual(wizard_refund.state, 'stage_1')
        wizard_refund.action_compile_data()
        self.assertEqual(wizard_refund.state, 'stage_2')
        wizard_refund.action_cancel()
        self.assertEqual(wizard_refund.state, 'stage_1')

    def test_action_compile_date_error(self):
        dic = {'data': ""}
        wizard_refund = self.env['fb.wizard_refunds'].create(dic)
        with self.assertRaises(exceptions.ValidationError):
            wizard_refund.action_compile_data()

    def test_action_compile_date_1(self):
        dic = {'data': "6815\n2248857022969\n"}
        wizard_refund = self.env['fb.wizard_refunds'].create(dic)
        wizard_refund.action_compile_data()
        self.assertEqual(len(wizard_refund.refunds_list), 1)
        self.assertEqual(wizard_refund.state, 'stage_2')

    def test_action_compile_date_2(self):
        """Test with unknown client"""
        dic = {'data': "9999\n2248857022969\n"}
        wizard_refund = self.env['fb.wizard_refunds'].create(dic)
        wizard_refund.action_compile_data()
        self.assertEqual(len(wizard_refund.refunds_list), 1)
        self.assertEqual(wizard_refund.state, 'stage_2')

    def test_action_compile_date_3(self):
        """Test with unknown product"""
        dic = {'data': "6815\n2199999999995\n"}
        wizard_refund = self.env['fb.wizard_refunds'].create(dic)
        wizard_refund.action_compile_data()
        self.assertEqual(len(wizard_refund.refunds_list), 1)
        self.assertEqual(wizard_refund.state, 'stage_2')

    def test_action_save_data(self):
        product = self.env.ref('fraichementbon.product_shaker')
        product.taxes_id = [self.ref('l10n_fr.tva_acq_reduite')]
        dic = {'data': "6815\n2248857022969\n"}
        wizard_refund = self.env['fb.wizard_refunds'].create(dic)
        wizard_refund.action_compile_data()
        self.assertEqual(wizard_refund.state, 'stage_2')
        res = wizard_refund.action_save_data()
        acc_invoice = self.env['account.invoice'].search(res['domain'])
        self.assertEqual(len(acc_invoice), 1)
        self.assertTrue(
            acc_invoice.amount_tax > 0
        )

    def test_action_save_multiple(self):
        product = self.env.ref('fraichementbon.product_shaker')
        product.taxes_id = [self.ref('l10n_fr.tva_acq_reduite')]
        dic = {
            'data': "6815\n2248857022969\n6854\n2248870026197\n2248857010003"
        }
        wizard_refund = self.env['fb.wizard_refunds'].create(dic)
        wizard_refund.action_compile_data()
        res = wizard_refund.action_save_data()
        self.assertEqual(
            len(self.env['account.invoice'].search(res['domain'])),
            2
        )

    def test_action_save_data_2(self):
        dic = {'data': "6815\n2199999999995\n"}
        wizard_refund = self.env['fb.wizard_refunds'].create(dic)
        wizard_refund.action_compile_data()
        self.assertEqual(wizard_refund.state, 'stage_2')
        with self.assertRaises(exceptions.ValidationError):
            wizard_refund.action_save_data()

    def test_update_data(self):
        line = self.env['fb.wizard_refund_line'].new({})
        line._update_data()

    def test_update_margin(self):
        line = self.env['fb.wizard_refund_line'].new({})
        line._update_margin()
