# -*- coding: utf-8 -*-
import os
from anybox.testing.openerp import TransactionCase
from .fbon_testcase import FraichementBonTransactionCase
from odoo_report_testing.assertions import OdooAssertions


class TestSoReport(FraichementBonTransactionCase, OdooAssertions):

    def test_simple_so_report(self):
        # Report must be predicatable
        sale = self.create_so(name="123")
        for report_line in sale.sale_order_line_report_ids:
            if report_line.product_id.id == self.ref(
                'fraichementbon.product_shaker'
            ):
                self.assertEqual(
                    3,
                    report_line.quantity
                )
                self.assertEqual(
                    4.91,
                    report_line.price
                )
            else:
                self.assertEqual(
                    5,
                    report_line.quantity
                )
                self.assertEqual(
                    16.78,
                    report_line.price
                )

        self.assertOdooReport(
            os.path.join(
                os.path.dirname(__file__),
                'expected_reports',
                'test_simple_so_report.pdf'
            ),
            'sale.order',
            'sale.report_saleorder',
            [sale.id],
            data={},
            context=None
        )


class TestSaleOrderLineReport(TransactionCase):

    def test_sol_report_model(self):
        sol_report = self.env.ref(
            'sale.sale_order_1'
        ).sale_order_line_report_ids
        self.assertTrue(len(sol_report) == 3)
        self.assertEqual(
            sum([l.price for l in sol_report]),
            # 3×2950+5×145+2×65 = 9705
            9705.00
        )


class TestSaleWithTaxes(FraichementBonTransactionCase):

    def assert_sale_tax_details(self, invoice, sale):
        self.assertEqual(
            sorted(
                [
                    dict(
                        name=tax.name, base=tax.base, amount=tax.amount
                    )
                    for tax in invoice.tax_line
                ],
                key=lambda k: k['name']
            ),
            sale.order_line.tax_line()
        )

    def test_tax_details(self):
        self.assert_sale_tax_details(self.create_invoice(), self.sale)

    def test_tax_details_multiple_taxes_by_product(self):
        self.ananas.taxes_id = [
            (6, 0, [self.tva_col_reduite.id, self.tva_vol_intermediaire.id])
        ]
        self.assert_sale_tax_details(self.create_invoice(), self.sale)
