# -*- coding: utf-8 -*-
{
    'name': 'Web Barcode reader',
    'version': '0.1',
    'sequence': 150,
    'category': 'custom',
    'author': 'Anybox',
    'website': 'http://anybox.fr',
    'depends': [
        'web',
    ],
    'data': [
        'views/web_barcode_reader.xml',
    ],
    'qweb': [
        "static/src/xml/*.xml",
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
    'license': 'AGPL-3',
}
