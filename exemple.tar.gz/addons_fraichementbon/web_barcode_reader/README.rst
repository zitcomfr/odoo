==================
Web barcode reader
==================

This widget allow to handle inputs from various devices (like barcode reader,
keyboard input, any other devices that simulate a keyboard...) to handle
specific behaviors.

How to and behaviours
---------------------

In your UI add a ``barcodereader`` tag where you want the barcode reader input
(at the moment an input type text is shown).

For instance here a way to add it above sale order lines on sale order form::

    <xpath expr="//form/sheet/notebook/page/field[@name='order_line']"
           position="before">
        <barcodereader onread="barcode_read"
                       attrs="{'invisible': [('state', '!=', 'draft')]}"/>
    </xpath>

On form view (not in edit mode) once you get focus on the input you can start
reading code bare.

Device need to send an `enter` key to call the method defined in the ``onread``
attribute (if not provide this widget expected `on_barecode_reader_read` method
on the model, the one manage by the formview). method signature looks like::


    @api.multi
    def barcode_read(self, barcode):
        return None

.. note::

    At the moment you ``self.ensure_one()`` will never raised.

Once the method is called only the view is refreshed.

TODO:

* interpret client side `on_barecode_reader_read` server side result to allow(
  server actions, refresh view, special show warnings)
* add a bip to indicated reading value was Ok or Nok that let know the user if
  the reading goes well.
* ...
