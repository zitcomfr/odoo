"use strict";
(function(){
    var instance = openerp;

    instance.web_barcode_reader = {};
    instance.web.form.BarcodeReader = instance.web.form.FormWidget.extend({
        template: 'BarcodeReader',
        on_read_method: 'on_barecode_reader_read',
        init: function(view, node){
            this._super(view, node);
            if(node.attrs.onread){
                this.on_read_method = node.attrs.onread;
            }
            this.view.on("change:actual_mode", this, this.check_actual_mode);
        },
        start: function(){
            this._super();
            this.input = this.$el.find('input[type="text"]');
            this.input.keyup(this.on_keyup);
            this.check_actual_mode();
        },
        check_actual_mode: function(){
            if (typeof this.input !== 'undefined' && this.input.prop !== 'undefined'){
                if(this.view.get('actual_mode') !== 'view'){
                    this.input.prop('disabled', true);
                }else{
                    this.input.prop('disabled', false);
                    this.input.focus();
                }
            }
        },
        on_keyup: function(event){
            //TODO: make sure this not depend on the depth of the tag
            // we should get the form view object
            var form = this.getParent();
            if(event.keyCode == 13)
            {
                var record = this.getParent().datarecord;
                var self = this;
                // clear input field before sending data to prevent getting
                // two bare code concatenate before sending to odoo server.
                var current_read = this.input[0].value;
                this.input[0].value = "";
                form.dataset._model.call(
                    this.on_read_method,
                    [
                        form.datarecord.id,
                        current_read
                    ],
                    {context: {}} //TODO: get a proper context
                ).then(function(result){
                    form.getParent().switch_mode(form.view_type).then(
                        function(){self.play_song('beep')}
                    );
                }).fail(function(){
                    self.play_song('error');
                });
                event.preventDefault();
            }
        },
        play_song: function(kind){
            var audio = this.$el.find('#' + kind)[0];
            audio.volume = 1;
            audio.currentTime = 0;
            audio.play();
        }
    });

    //TODO: getting focus when switching record

    instance.web.form.tags.add(
        'barcodereader',
        'instance.web.form.BarcodeReader'
    );

})();